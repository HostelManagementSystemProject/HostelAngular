import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'editresident',
  templateUrl: './editresident.component.html',
  styleUrls: ['./editresident.component.css']
})
export class EditresidentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
