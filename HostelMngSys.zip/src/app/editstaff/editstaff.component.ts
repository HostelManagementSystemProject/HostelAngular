import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'editstaff',
  templateUrl: './editstaff.component.html',
  styleUrls: ['./editstaff.component.css']
})
export class EditstaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
