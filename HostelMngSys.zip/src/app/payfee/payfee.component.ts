import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PaymentService } from '../Payments/payment.service';

@Component({
  selector: 'payfee',
  templateUrl: './payfee.component.html',
  styleUrls: ['./payfee.component.css']
})
export class PayfeeComponent implements OnInit {

  @Input()
  public pay_fee={payment_id:'', due_date:'', date_of_payment:'', receipt_no:''};
  
  constructor(public restApi: PaymentService,
    public router: Router) { }

  ngOnInit(){
    }

  addPayment(){
    this.restApi.payfees(this.pay_fee).subscribe((data:{}) => { this.router.navigate(['/home'])})
  }


 

}
