import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'payfee',
  templateUrl: './payfee.component.html',
  styleUrls: ['./payfee.component.css']
})
export class PayfeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
