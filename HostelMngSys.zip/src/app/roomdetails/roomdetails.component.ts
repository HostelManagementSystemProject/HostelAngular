import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'roomdetails',
  templateUrl: './roomdetails.component.html',
  styleUrls: ['./roomdetails.component.css']
})
export class RoomdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
