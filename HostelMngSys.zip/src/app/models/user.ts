import { Role } from './role';

export class User {
  Role: Role;
}
