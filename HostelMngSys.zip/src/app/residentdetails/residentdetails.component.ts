import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'residentdetails',
  templateUrl: './residentdetails.component.html',
  styleUrls: ['./residentdetails.component.css']
})
export class ResidentdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
