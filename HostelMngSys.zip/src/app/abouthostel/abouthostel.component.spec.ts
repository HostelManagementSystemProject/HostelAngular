import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AbouthostelComponent } from './abouthostel.component';

describe('AbouthostelComponent', () => {
  let component: AbouthostelComponent;
  let fixture: ComponentFixture<AbouthostelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AbouthostelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AbouthostelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
