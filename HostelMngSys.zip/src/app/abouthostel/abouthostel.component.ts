import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'abouthostel',
  templateUrl: './abouthostel.component.html',
  styleUrls: ['./abouthostel.component.css']
})
export class AbouthostelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
