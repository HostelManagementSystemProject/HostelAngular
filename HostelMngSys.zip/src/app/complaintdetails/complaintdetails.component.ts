import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'complaintdetails',
  templateUrl: './complaintdetails.component.html',
  styleUrls: ['./complaintdetails.component.css']
})
export class ComplaintdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
