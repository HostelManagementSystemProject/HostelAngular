import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
