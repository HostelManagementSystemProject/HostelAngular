export interface Payment{
    payment_id: number,
    due_date: Date,
    date_of_payemnt: Date,
    receipt_no: number
}