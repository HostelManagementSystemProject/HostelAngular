import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'addstaff',
  templateUrl: './addstaff.component.html',
  styleUrls: ['./addstaff.component.css']
})
export class AddstaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
