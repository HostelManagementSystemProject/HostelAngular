export interface Complaints{
    complaint_id: number,
    complaint_name: String,
    particulars: String,
    status: String
}