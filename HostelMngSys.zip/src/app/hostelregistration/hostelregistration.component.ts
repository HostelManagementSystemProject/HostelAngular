import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hostelregistration',
  templateUrl: './hostelregistration.component.html',
  styleUrls: ['./hostelregistration.component.css']
})
export class HostelregistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
