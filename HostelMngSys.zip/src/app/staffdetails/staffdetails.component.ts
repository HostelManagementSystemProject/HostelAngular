import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'staffdetails',
  templateUrl: './staffdetails.component.html',
  styleUrls: ['./staffdetails.component.css']
})
export class StaffdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
